/******************* 
@Purpose : Used for import all langauge
@Author : INIC
******************/

export * from "./En";
export * from "./Fr";
export * from "./Gr";
export * from "./Po";
